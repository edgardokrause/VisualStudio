-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 23-10-2020 a las 22:32:57
-- Versión del servidor: 5.7.11
-- Versión de PHP: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `libreria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `t_libro`
--

CREATE TABLE `t_libro` (
  `Id` int(11) NOT NULL,
  `isbn` varchar(50) NOT NULL,
  `titulo` varchar(50) NOT NULL,
  `descripcion` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `t_libro`
--

INSERT INTO `t_libro` (`Id`, `isbn`, `titulo`, `descripcion`) VALUES
(3, '23423', 'sarasa', 'sarasa'),
(4, '23232', 'sarasa2', 'sarasa2'),
(5, '999999999', 'saras2a', 'sarasa2'),
(6, '23232', 'sarasa2', 'sarasa2'),
(8, '23232', 'sarasa3', 'sarasa3'),
(9, '23423', 'NUEVAAA', 'sarasa'),
(14, '2345', 'sdff', 'sdf'),
(15, '45345', 'sdfs', 'dfdfdfsfsdfsdf'),
(16, '2345', 'df', 'dff'),
(17, '234', 'dsfsdf', 'sdfdf');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `t_libro`
--
ALTER TABLE `t_libro`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `t_libro`
--
ALTER TABLE `t_libro`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
