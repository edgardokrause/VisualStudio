<?php
	include('config.php');

	$id=$_GET['Id'];
	$isbn=$_GET['isbn'];
	$titulo=$_GET['titulo'];
	$descripcion=$_GET['descripcion'];

	$query = " UPDATE t_libro SET isbn= '$isbn',titulo= '$titulo', descripcion= '$descripcion' where Id= '$id' ";

	$ses_sql = mysqli_query($db,$query);
    $datosini = array(['Resultado'=> 'Ok']);
	$json_string = json_encode($datosini);
	echo $json_string;
	
			
?>