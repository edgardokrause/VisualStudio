<?php

include ('config.php');

$query= ("SELECT * FROM t_libro ORDER BY Id ASC");
$accion=mysqli_query($db, $query);
$resultado=mysqli_fetch_all($accion, MYSQLI_ASSOC);
$resultadojson=json_encode($resultado);
echo$resultadojson;

?>