<?php
include('config.php');
	$Id=$_GET['Id'];

	$query = "delete from t_libro where Id=$Id";
	echo $query;
	$ses_sql = mysqli_query($db,$query);
    $datosini = array(['Resultado'=> 'Ok']);
	$json_string = json_encode($datosini);
	echo $json_string;
	
?>
