<?php
	include('config.php');

$isbn=$_GET['isbn'];
$titulo=$_GET['titulo'];
$descripcion=$_GET['descripcion'];


	$query = "insert into t_libro (`isbn`, `titulo`, `descripcion`) values (".$isbn.",'".$titulo."','".$descripcion."')";

	$ses_sql = mysqli_query($db,$query);
    $datosini = array(['Resultado'=> 'Ok']);
	$json_string = json_encode($datosini);
	echo $json_string;
	
			
?>
