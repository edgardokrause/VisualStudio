<?php

$datosini=parse_ini_file('config.ini');
$servidor=$datosini['servidor'];
$database=$datosini['database'];
$usuario=$datosini['usuario'];
$clave=$datosini['clave'];

define('DB_SERVER',$servidor);
define('DB_DATABASE',$database);
define('DB_USERNAME',$usuario);
define('DB_PASSWORD',$clave);

$db = Mysqli_connect (DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
?>